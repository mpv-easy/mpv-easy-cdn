--[[
    mpv_crop_script.lua {version} - commit {commit_short} (branch {branch})
    Built on {utc_now:%Y-%m-%d %H:%M:%S}
]]--
