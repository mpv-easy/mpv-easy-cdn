# persist-properties

Lua script for [mpv](https://mpv.io/) to keep selected values like volume between player sessions.

An example configuration _(script-opts/persist_properties.conf)_ :
```
properties=volume,sub-scale
```