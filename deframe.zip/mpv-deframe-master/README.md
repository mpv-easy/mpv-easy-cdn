# mpv sin marcos de youtube

presiona **g** para quitar el marco


~~~
mkdir -p ~/.config/mpv/scripts/
cp *lua ~/.config/mpv/scripts/
sudo cp deframe/usr/local/bin/
~~~

Requiere:
---------

* ffmpegthumbnailer
* imagemagick

--

**Bitcoin:** 19qkh5dNVxL58o5hh6hLsK64PwEtEXVHXs    
**PayPal:** [Done $1](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JMFARRBCYTFG8)

