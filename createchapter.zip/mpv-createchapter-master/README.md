# createchapter
Simple chapter maker with ability to export valid xml chapter file.

## Usage
Place the [`createchapter.lua`][link] file into mpv scripts folder.

## Keybind
`Shift-c` - Mark chapters

`Shift-b` - Export xml file

[link]: https://github.com/shinchiro/mpv-createchapter/raw/master/createchapter.lua
