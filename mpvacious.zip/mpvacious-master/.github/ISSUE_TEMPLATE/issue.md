---
name: Developer Tasks
about: For bug reports, suggestions and support, please see the options below.
title: ""
labels: ""
assignees: ""
---

- The add-on stopped working?
- Have a question or feature suggestion?
- Not 100% sure you've found a bug?

If so, please ask on https://tatsumoto.neocities.org/blog/join-our-community.html instead.
This issue tracker is intended primarily to track development tasks,
and it is easier for our members to provide support over in the chats.
Thank you!

If you post questions, suggestions, or vague bug reports here,
please do not be offended if we close your ticket without replying.
If in doubt, please post on https://tatsumoto.neocities.org/blog/join-our-community.html instead.
