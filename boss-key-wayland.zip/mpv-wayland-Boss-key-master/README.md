# rewrite of Boss Key mpv extention for Wayland
rather than using hacky methods like xtodo or ... use mpv own API/ABI to pause and, minimize mpv.

Add to input.conf:
```
b script-binding minimize-window
```

#  Copyright

mpv wayland Boss-key is released under version 3 or later of the GPL, the GNU General Public License.

See [license.txt](license.txt).

The author of mpv wayland Boss-key:

- Copyright (C) 2023-2024 Mohammadreza Hendiani `<man2dev@fedoraproject.org>`
