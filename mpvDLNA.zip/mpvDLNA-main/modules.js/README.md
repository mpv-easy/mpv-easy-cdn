# This code is originally from [VideoPlayerCode](https://github.com/VideoPlayerCode)'s 
# [mpv-tools](https://github.com/VideoPlayerCode/mpv-tools/) repository under the [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.html).
## The SelectionMenu.js and Options.js files have been modified to better work with mpvDLNA but the other files are still in their original form.
