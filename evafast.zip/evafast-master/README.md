# evafast
Fast-forwarding and seeking on a single key, with quality of life features like a slight slowdown when subtitles are shown.

## Installation
Place evafast.lua in your mpv `scripts` folder.

## Usage
Tap right arrow key to seek like default mpv, hold it down to fast-forward.  
Playback speed will smoothly ramp up and wind back down.

Provides the `evafast/toggle` script-binding for speeding up independently of the hybrid key.