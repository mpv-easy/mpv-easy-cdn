# open-dir
A simple script that opens the current path of the file in the file explorer
the default key to run this script is *ctrl+d*, you can change it in the line 9.
