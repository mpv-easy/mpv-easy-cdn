---@meta file-browser

return require 'modules.apis.fb'
