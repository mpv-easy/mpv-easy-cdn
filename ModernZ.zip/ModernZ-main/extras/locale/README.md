The different locales (languages) for ModernZ OSC are stored within the [modernz-locale.json](/extras/locale/modernz-locale.json) file.

For more information: [Translations](/docs/TRANSLATIONS.md)
