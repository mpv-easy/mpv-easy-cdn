# trackselect
Automatically select your preferred tracks based on title, because --slang isn't smart enough.

## Installation
Place trackselect.lua in your mpv `scripts` folder.

## Usage
Play a file with english audio and/or a "Signs/Songs" track set as default.  
Default settings will select non-dub audio and subtitle tracks (intended for anime).