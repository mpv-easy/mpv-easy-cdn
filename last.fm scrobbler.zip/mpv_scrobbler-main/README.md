# mpv_scrobbler
An over-engineered last.fm scrobbler for mpv player
