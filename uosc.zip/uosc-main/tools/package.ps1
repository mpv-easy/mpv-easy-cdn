& "$PSScriptRoot/tools.exe" package $args
