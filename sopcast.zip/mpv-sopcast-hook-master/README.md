mpv-sopcast-hook
------------------
sopcast hook for mpv. open sop:// urls automatical.

Usage
-----
1. Move this script to ~/.config/mpv/scripts
2. Make sure sp-sc-auth/sp-sc is in your $PATH or in ~/.config/mpv
3. Install [luasocket](https://github.com/diegonehab/luasocket)