ITEM **create_meta_items(char ***metadata);
ITEM **create_path_items(char ***entries);
void create_visual_window(struct vmn_library *lib);
void destroy_last_menu_meta(struct vmn_library *lib);
void destroy_last_menu_path(struct vmn_library *lib);
void destroy_visual_window(struct vmn_library *lib);
