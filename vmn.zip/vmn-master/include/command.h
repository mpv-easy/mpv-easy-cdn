void init_command_mode(struct vmn_config *cfg, struct vmn_library *lib);
