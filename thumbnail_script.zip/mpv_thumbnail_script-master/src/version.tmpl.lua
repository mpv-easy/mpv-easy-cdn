--[[
    mpv_thumbnail_script.lua {version} - commit {commit_short} (branch {branch})
    https://github.com/TheAMM/mpv_thumbnail_script
    Built on {utc_now:%Y-%m-%d %H:%M:%S}
]]--
