# rename-sub
Rename current subtitle file as the playing video and move it to the same directory as the video.
