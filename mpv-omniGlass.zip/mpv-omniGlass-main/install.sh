 gcc -o ~/.config/mpv/scripts/omniglass.so mpv-omniGlass.c -shared -fPIC -lomniglass_linux
