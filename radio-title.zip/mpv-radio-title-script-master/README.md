Moved to [Codeberg](https://codeberg.org/olivierlm/mpv-radio-title-script)
