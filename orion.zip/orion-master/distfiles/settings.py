# Settings for dmgbuild

files       = [ 'orion.app' ]
symlinks    = { 'Applications': '/Applications' }
