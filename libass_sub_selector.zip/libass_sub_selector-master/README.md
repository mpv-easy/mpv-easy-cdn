# libass_sub_selector
Visually select individual subtitles a la PotPlayer.

[Preview](https://too.lewd.se/bb9fafdc5a88_preview.mp4)

## Requirements
- libass

## Installation
Place libass_sub_selector.lua in your mpv `scripts` folder.

## Usage
Hover on a subtitle, press c to copy its contents.