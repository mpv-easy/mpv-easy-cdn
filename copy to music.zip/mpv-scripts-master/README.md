# mpv-scripts

## Well, what is mpv?
[mpv](https://github.com/mpv-player/mpv) is a very extensible media player which I like. Please give them a star for their great work!

## My mpv scripts

### Copy To Music
#### Requirements: 
    - Unix System
    - Defined "$MUSIC" variable that points to your music directory.
A basic script where if you press "ctrl-m", it copies the current media file you're playing to a predefined directory, and plays the next entry in the playlist (if any). Saves you the time of manually looking up files and copying them. 
