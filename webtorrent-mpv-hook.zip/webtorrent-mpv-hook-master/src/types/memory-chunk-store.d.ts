declare module 'memory-chunk-store' {
  function Storage(...args: unknown[]): unknown;
  export = Storage;
}
