# Load Danmaku


## Description

This is a lua script for mpv player. It will load danmaku files (`.xml`) in the current directory.

## Requirements

+ Need [Danmaku2ASS](https://github.com/m13253/danmaku2ass) to be installed.

+ Need [Lua CJSON](https://www.kyne.com.au/~mark/software/lua-cjson-manual.html) to be installed.
