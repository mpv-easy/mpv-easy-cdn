# mpv_irc
Display lines from an IRC channel or any text file.

## Installation
Place irc.lua in your mpv `scripts` folder.  
You can also copy scrollingsubs.lua and syncplayintf.lua for alternative display methods.

## Usage
Set the log_file script option and activate the script with X (shift+x).  
New lines from your log file will be displayed using the OSD.