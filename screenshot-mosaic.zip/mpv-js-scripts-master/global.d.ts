declare function setTimeout(cb: () => void, ms: number): number;
declare function setInterval(cb: () => void, ms: number): number;
declare function clearInterval(id: number): void;
declare function clearTimeout(id: number): void;