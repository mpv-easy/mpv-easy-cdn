# mpv delogo

Presionar **n** para quitar el logo

~~~
mkdir -p ~/.config/mpv/scripts/
cp *lua ~/.config/mpv/scripts/
sudo cp delogo /usr/local/bin/
~~~

Requiere:
---------

* ffmpegthumbnailer
* imagemagick

--

**Bitcoin:** 19qkh5dNVxL58o5hh6hLsK64PwEtEXVHXs    
**PayPal:** [Done $1](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JMFARRBCYTFG8)
