Moved to [Codeberg](https://codeberg.org/olivierlm/mpv-spotify-script)
