# mpv-chapters
Display chapters and allow you to jump to them with a mouse click.

## usage
Press tab to toggle chapter menu.

preview:

![Imgur](https://i.imgur.com/f7WtKYN.png)
