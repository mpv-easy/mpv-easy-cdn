#!/bin/sh
make install ; make test-clean ; make test
